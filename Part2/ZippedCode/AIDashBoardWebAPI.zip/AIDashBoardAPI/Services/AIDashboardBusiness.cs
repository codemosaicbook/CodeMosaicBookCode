﻿using AIDashBoardWebAPI.Data;

namespace AIDashBoardWebAPI.Services
{
    /// <summary>
    /// Business logic layer for the AI Dashboard. This class handles operations and transformations
    /// on data retrieved from the data layer to prepare it for presentation or further processing.
    /// </summary>
    public class AIDashboardBusiness
    {
        private readonly IAIDashboardData _dataLayer;

        /// <summary>
        /// Constructor for AIDashboardBusiness. Initializes a new instance of the business layer with the given data layer.
        /// </summary>
        /// <param name="dataLayer">The data layer instance to use for data retrieval and operations.</param>
        public AIDashboardBusiness(IAIDashboardData dataLayer)
        {
            _dataLayer = dataLayer;
        }

        /// <summary>
        /// Asynchronously retrieves and processes project metrics data to prepare data for a pie chart.
        /// </summary>
        /// <returns>A task that represents the asynchronous operation. The task result contains a list of PieChartDataModel.</returns>
        public async Task<List<PieChartDataModel>> GetPieChartDataAsync()
        {
            // Retrieve raw data from the data layer
            var projectMetrics = await _dataLayer.GetProjectMetricsAsync();

            // Process the data: Group by AI_Impact_Area and sum EfficiencyImprovement
            var groupedData = projectMetrics
                .GroupBy(metric => metric.AI_Impact_Area)
                .Select(group => new PieChartDataModel
                {
                    Category = group.Key,
                    Value = group.Sum(metric => metric.EfficiencyImprovement),
                })
                .ToList();

            return groupedData;
        }

        /// <summary>
        /// Asynchronously retrieves and processes project metrics data to prepare data for a stacked bar chart.
        /// </summary>
        /// <returns>A task that represents the asynchronous operation. The task result contains a list of StackedBarChartDataModel.</returns>
        public async Task<List<StackedBarChartDataModel>> GetStackedBarChartDataAsync()
        {
            var projectMetrics = await _dataLayer.GetProjectMetricsAsync();

            // Process data for stacked bar chart: Map each metric to a StackedBarChartDataModel
            var stackedBarChartData = projectMetrics.Select(metric => new StackedBarChartDataModel
            {
                ProjectName = metric.ProjectName,
                EfficiencyImprovement = metric.EfficiencyImprovement,
                AIDrivenFeatureCount = metric.AIDrivenFeatureCount,
                BugCountReduction = metric.BugCountBeforeAI - metric.BugCountAfterAI,
                TimeSaved = metric.DevelopmentTimeBeforeAI - metric.DevelopmentTimeAfterAI,
                AITechnologyUsed = metric.AI_Technology_Used
            }).ToList();

            return stackedBarChartData;
        }
    }
}
