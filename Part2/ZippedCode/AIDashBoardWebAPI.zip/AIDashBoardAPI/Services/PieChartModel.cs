﻿namespace AIDashBoardWebAPI.Services
{
    public class PieChartDataModel
    {
        public string? Category { get; set; }
        public double Value { get; set; }
    }

}
