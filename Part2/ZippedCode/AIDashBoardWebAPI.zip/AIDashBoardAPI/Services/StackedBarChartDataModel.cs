﻿namespace AIDashBoardWebAPI.Services
{
    public class StackedBarChartDataModel
    {
        public string? ProjectName { get; set; }
        public double EfficiencyImprovement { get; set; }
        public int AIDrivenFeatureCount { get; set; }
        public int BugCountReduction { get; set; }
        public int TimeSaved { get; set; }
        public string? AITechnologyUsed { get; set; }
    }
}
