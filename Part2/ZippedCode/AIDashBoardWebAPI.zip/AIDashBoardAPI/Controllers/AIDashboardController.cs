﻿using AIDashBoardWebAPI.Data;
using AIDashBoardWebAPI.Services;
using Microsoft.AspNetCore.Mvc;

namespace AIDashBoardWebAPI.Controllers
{

    [ApiController]
    [Route("api/[controller]")]
    public class AIDashboardController : ControllerBase
    {
        private readonly AIDashboardBusiness _businessLayer;
        private readonly AIDashboardData _dataLayer;

        public AIDashboardController(AIDashboardBusiness businessLayer, AIDashboardData dataLayer)
        {
            _businessLayer = businessLayer;
            _dataLayer = dataLayer;
        }

        [HttpGet("GetGridData")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<ActionResult<IEnumerable<ProjectMetrics>>> GetGridData()
        {
            var gridData = await _dataLayer.GetProjectMetricsAsync();
            return Ok(gridData);
        }

        [HttpGet("GetPieChartData")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<ActionResult<IEnumerable<PieChartDataModel>>> GetPieChartData()
        {
            var pieData = await _businessLayer.GetPieChartDataAsync();
            return Ok(pieData);
        }

        [HttpGet("GetStackedBarChartData")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<ActionResult<IEnumerable<ProjectMetrics>>> GetStackedBarChartData()
        {
            var stackedData = await _businessLayer.GetStackedBarChartDataAsync();
            return Ok(stackedData);
        }

    }


}
