﻿using Microsoft.EntityFrameworkCore;

namespace AIDashBoardWebAPI.Data
{
    /// <summary>
    /// Defines the interface for AI Dashboard data operations, particularly for managing ProjectMetrics.
    /// </summary>
    public interface IAIDashboardData
    {
        /// <summary>
        /// Asynchronously retrieves a list of ProjectMetrics.
        /// </summary>
        /// <returns>A task that represents the asynchronous operation. The task result contains a list of ProjectMetrics.</returns>
        Task<List<ProjectMetrics>> GetProjectMetricsAsync();
    }

    /// <summary>
    /// Provides implementation for AI Dashboard data operations and acts as a data context for Entity Framework.
    /// </summary>
    public class AIDashboardData : DbContext, IAIDashboardData
    {
        /// <summary>
        /// Initializes a new instance of the AIDashboardData class.
        /// </summary>
        /// <param name="options">The options to be used by the DbContext.</param>
        public AIDashboardData(DbContextOptions<AIDashboardData> options) : base(options) { }

        /// <summary>
        /// Gets or sets the DbSet for ProjectMetrics entities.
        /// </summary>
        public DbSet<ProjectMetrics> ProjectMetrics { get; set; }

        /// <summary>
        /// Asynchronously retrieves project metrics by executing a stored procedure and returning the results.
        /// </summary>
        /// <returns>A task that represents the asynchronous operation. The task result contains a list of ProjectMetrics.</returns>
        public async Task<List<ProjectMetrics>> GetProjectMetricsAsync()
        {
            // Call the stored procedure 'usp_GetProjectMetrics' and return the results as a list
            try
            {
                return await ProjectMetrics.FromSqlRaw("EXEC usp_GetProjectMetrics").ToListAsync();

            }
            catch (Exception e)
            {

                throw;
            }
        }

        /// <summary>
        /// Configures the schema needed for the model when the model is created.
        /// This method is called when the data context is first created to build the model and its mappings in memory.
        /// </summary>
        /// <param name="modelBuilder">Defines the shape of your entities, the relationships between them, and how they map to the database.</param>
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            // Place additional model configuration here. For example, configuring relationships or setting default values.
        }
    }
}
