﻿using System.ComponentModel.DataAnnotations;

namespace AIDashBoardWebAPI.Data
{
    public class ProjectMetrics
    {
        [Key]
        public int ProjectID { get; set; }
        public string? ProjectName { get; set; }
        public string? AIIntegrationLevel { get; set; }
        public double EfficiencyImprovement { get; set; }
        public int FeatureCount { get; set; }
        public int AIDrivenFeatureCount { get; set; }
        public int BugCountBeforeAI { get; set; }
        public int BugCountAfterAI { get; set; }
        public int DevelopmentTimeBeforeAI { get; set; }
        public int DevelopmentTimeAfterAI { get; set; }
        public string? AI_Technology_Used { get; set; }
        public string? AI_Impact_Area { get; set; }
    }

}
