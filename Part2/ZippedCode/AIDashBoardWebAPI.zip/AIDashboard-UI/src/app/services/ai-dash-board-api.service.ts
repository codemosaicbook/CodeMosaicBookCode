import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { HttpClientModule } from '@angular/common/http'; // <-- Import HttpClientModule

@Injectable({
  providedIn: 'root',
})
export class AiDashBoardApiService {
  // Replace with your actual API URL
  private BASE_URL = 'https://aidashboardcodemosaic.azurewebsites.net/api';

  constructor(private http: HttpClient) {}

  getGridData(): Observable<any> {
    return this.http.get(`${this.BASE_URL}/AIDashboard/GetGridData`);
  }

  getPieChartData(): Observable<any> {
    return this.http.get(`${this.BASE_URL}/AIDashboard/GetPieChartData`);
  }

  getStackedBarChartData(): Observable<any> {
    return this.http.get(`${this.BASE_URL}/AIDashboard/GetStackedBarChartData`);
  }
}
