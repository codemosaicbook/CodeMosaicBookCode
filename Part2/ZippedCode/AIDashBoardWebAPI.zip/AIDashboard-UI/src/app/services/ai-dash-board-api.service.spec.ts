import { TestBed } from '@angular/core/testing';

import { AiDashBoardApiService } from './ai-dash-board-api.service';

describe('AiDashBoardApiService', () => {
  let service: AiDashBoardApiService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AiDashBoardApiService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
