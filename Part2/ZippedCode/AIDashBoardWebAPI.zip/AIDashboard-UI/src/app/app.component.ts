import { Component, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet } from '@angular/router';
import { AiDashBoardApiService } from '../app/services/ai-dash-board-api.service';
import { HttpClientModule } from '@angular/common/http'; // <-- Import HttpClientModule
import { Subscription } from 'rxjs';
import { DxDataGridModule, DxPieChartModule, DxChartModule } from 'devextreme-angular';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet,
    HttpClientModule,DxDataGridModule,
    DxPieChartModule,
    DxChartModule],
    providers: [AiDashBoardApiService],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnDestroy {
  title = 'AIDashboard-UI';
  private subscriptions: Subscription[] = [];
  gridData: any[] = []; // Variable to store grid 
  pieChartData: any[] = [];
  stackedBarChartData: any[] = [];

  constructor(private aiDashboardApiService: AiDashBoardApiService) { 
    this.fetchData();
  }

  private fetchData(): void {
    this.subscriptions.push(
      this.aiDashboardApiService.getGridData().subscribe({
        next: data => this.gridData = data,
        error: error => console.error('Error fetching grid data:', error)
      }),

      this.aiDashboardApiService.getPieChartData().subscribe({
        next: data => this.pieChartData = data,
        error: error => console.error('Error fetching pie chart data:', error)
      }),

      this.aiDashboardApiService.getStackedBarChartData().subscribe({
        next: data => this.stackedBarChartData = data,
        error: error => console.error('Error fetching stacked bar chart data:', error)
      })
    );
  }

  ngOnDestroy(): void {
    // Unsubscribe from all subscriptions
    this.subscriptions.forEach(sub => sub.unsubscribe());
  }
   // Customize text for pie chart labels
   customizeText = (arg: any): string => {
    // 'arg' contains information about the point (e.g., value, argument, etc.)
    return `${arg.argumentText}: ${arg.valueText}`;
  }

  // Customize tooltip content
  customizeTooltip = (arg: any): string => {
    // 'arg' contains information about the point (e.g., value, argument, etc.)
    // You can return HTML string for rich content
    return `
      <div>
        <p><strong>Category:</strong> ${arg.argumentText}</p>
        <p><strong>Value:</strong> ${arg.valueText}</p>
        <!-- Add more details if needed -->
      </div>
    `;
  }

}